# -*- coding: utf-8 -*-

from . import einvoice_serie
from . import account_invoice
from . import product_template
from . import res_partner
from . import models
from . import product_uom
from . import sale
from . import pos_invoice
from . import pos_order
from . import guia_remision

# from . import sale_make_invoice_advance
#from . import einvoice_import_wizard
#from . import contingencia_wizard

